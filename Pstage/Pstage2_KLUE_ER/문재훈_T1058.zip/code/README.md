# Pstage_03_KLUE_Relation_extraction

### training
* python train.py

### inference
* python inference.py --model_dir=[model_path]
* ex) python inference.py --model_dir=./results/checkpoint-2000

### evaluation
* python eval_acc.py
